<?php $__env->startSection('title'); ?>
    Change Password
<?php $__env->stopSection(); ?>

<div>
    <?php if($this->success_message): ?>
    <div class="alert alert-success" role="alert">
        <?php echo e($this->success_message); ?>

    </div>
    <?php endif; ?>
    
    <div class="card-body">
        <form wire:submit.prevent="changePassword" class="mb-5">
         <?php echo e(csrf_field()); ?>

           <div class="form-row">
               <div class="col form-group">
                   <label>Current Password</label>
                     <input wire:model.defer="current_password" type="password" class="form-control" >
                     <?php $__errorArgs = ['current_password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                         <span class="text-danger">
                             <?php echo e($message); ?>

                         </span>
                     <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
               </div> <!-- form-group end.// -->
            </div>
               <div class="form-row">
                <div class="col form-group">
                    <label>New Password</label>
                      <input wire:model.defer="new_password" type="password" class="form-control">
                      <small class="form-text text-muted">New password must contain at least 8 characters.</small>
                      <?php $__errorArgs = ['new_password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                         <span class="text-danger">
                             <?php echo e($message); ?>

                         </span>
                     <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div> <!-- form-group end.// -->
            </div> <!-- form-row.// -->
          
 
           <div class="form-row">
             <div class="col form-group">
                 <label>Confirm New Password</label>
                   <input wire:model.defer="new_confirm_password" type="password" class="form-control">
                   <?php $__errorArgs = ['new_confirm_password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                         <span class="text-danger">
                             <?php echo e($message); ?>

                         </span>
                     <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
             </div> <!-- form-group end.// -->
         </div> <!-- form-row.// -->
        
           <button class="btn btn-primary btn-block">Change Password</button>
         </form>
         </div> 
</div>
<?php /**PATH T:\laragon\www\Laravel\Emart-system\resources\views/livewire/user/change-password.blade.php ENDPATH**/ ?>