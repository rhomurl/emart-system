<div class="widget-header">
    <a href="<?php echo e(route('cart')); ?>" class="widget-view">
        <div class="icon-area">
            <i class="fa fa-shopping-cart">
                <span class="notify">
                    <?php if($cartAmount < 9): ?>
                        <?php echo e($cartAmount); ?>

                    <?php else: ?>
                        9+
                    <?php endif; ?>
                </span>
            </i>
        </div>
        <small class="text"> Cart </small>
    </a>
</div>

<?php /**PATH T:\laragon\www\Laravel\Emart-system\resources\views/livewire/shop/cart-icon.blade.php ENDPATH**/ ?>