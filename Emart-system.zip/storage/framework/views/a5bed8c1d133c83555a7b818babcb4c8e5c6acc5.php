<section class="section-content padding-y">
    <div class="container">
    
    <nav class="row">
        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-md-3">
                
                <div class="card mb-3">
                  <div class="img-wrap" style="background: #ffd7d7">
                    <a href="<?php echo e(route('product.details', $category->slug )); ?>">
                      <img src="images/items/1.jpg">
                    </a>
                    </div>
                  <div class="card-body">
                    <h4 class="card-title"><a href="#"><?php echo e($category->name); ?></a></h4>
                  </div>
                </div>
            </div> <!-- col.// -->
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </section><?php /**PATH T:\laragon\www\Laravel\Emart-system\resources\views/livewire/shop/category-page.blade.php ENDPATH**/ ?>