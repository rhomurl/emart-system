<?php $__env->startSection('title'); ?>
    Add Address    
<?php $__env->stopSection(); ?>
<div>
    <div class="card mb-4">
        <?php if($this->error_message): ?>
        <div class="alert alert-warning" role="alert">
            <?php echo e($this->error_message); ?>

        </div>
        <?php endif; ?>
        <div class="col md-3 p-3">
            <a href="<?php echo e(route('user.address')); ?>" class="btn btn-primary float-md-left"><i class="fa fa-chevron-left"></i> Back to My Address </a>
        </div>
        <div class="card-body">
       <form wire:submit.prevent="storeAddress" class="mb-5">
        <?php echo e(csrf_field()); ?>

          <div class="form-row">
              <div class="col form-group">
                  <label>Name</label>
                    <input wire:model="entry_firstname" name="entry_firstname" type="text" class="form-control" value="" required>
                    <?php $__errorArgs = ['entry_firstname'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-danger">
                            <?php echo e($message); ?>

                        </span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
              </div> <!-- form-group end.// -->
              <div class="col form-group">
                  <label>Last Name</label>
                    <input wire:model="entry_lastname" name="entry_lastname" type="text" class="form-control" value="" required>
                    <?php $__errorArgs = ['entry_lastname'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-danger">
                            <?php echo e($message); ?>

                        </span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
              </div> <!-- form-group end.// -->
          </div> <!-- form-row.// -->

          <div class="form-row">
            <div class="col form-group">
                <label>Company</label>
                  <input wire:model="entry_company" name="entry_company" type="text" class="form-control" value="">
                  <?php $__errorArgs = ['entry_company'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-danger">
                            <?php echo e($message); ?>

                        </span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div> <!-- form-group end.// -->
            <div class="col form-group">
                <label>Landmark</label>
                  <input wire:model="entry_landmark" name="entry_landmark" type="text" class="form-control" value="">
                  <?php $__errorArgs = ['entry_landmark'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-danger">
                            <?php echo e($message); ?>

                        </span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div> <!-- form-group end.// -->
        </div> <!-- form-row.// -->

          <div class="form-row">
            <div class="col form-group">
                <label>Street Address</label>
                  <input wire:model="entry_street_address" name="entry_street_address" type="text" class="form-control" value="" required>
                  <?php $__errorArgs = ['entry_street_address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-danger">
                            <?php echo e($message); ?>

                        </span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div> <!-- form-group end.// -->
        </div> <!-- form-row.// -->
          
          <div class="form-row">
              
            <div class="form-group col-md-6">
                <label>City</label>
                <select wire:model="city" name="city" class="form-control" required>
                    <option value="">-- choose city --</option>
                    <?php $__currentLoopData = $cities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($city->id); ?>"><?php echo e($city->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div class="col-md-6">
                <label>Barangay</label>
                <select wire:model="barangay" name="barangay" class="form-control" required>
                    <?php if($barangays->count() == 0): ?>
                        <option value="">-- choose city first --</option>
                    <?php endif; ?>
                    <?php $__currentLoopData = $barangays; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $barangay): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($barangay->id); ?>"><?php echo e($barangay->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
          </div> <!-- form-row.// -->
  
          <div class="form-row">
              <div class="form-group col-md-6">
                <label>Phone</label>
                <input wire:model="entry_phonenumber" name="entry_phonenumber" type="text" class="form-control" placeholder="+639152390900" required>
                <?php $__errorArgs = ['entry_phonenumber'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="text-danger">
                        <?php echo e($message); ?>

                    </span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
              </div> <!-- form-group end.// -->
          </div> <!-- form-row.// -->
  
          <button class="btn btn-primary btn-block">Save Address</button>
        </form>
        </div> <!-- card-body.// -->
      </div>
</div>
<?php /**PATH T:\laragon\www\Laravel\Emart-system\resources\views/livewire/user/address-create.blade.php ENDPATH**/ ?>