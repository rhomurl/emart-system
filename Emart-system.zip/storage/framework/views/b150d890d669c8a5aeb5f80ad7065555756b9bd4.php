<?php $attributes = $attributes->exceptProps(['formAction' => false]); ?>
<?php foreach (array_filter((['formAction' => false]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>

<div>
    <?php if($formAction): ?>
        <form wire:submit.prevent="<?php echo e($formAction); ?>">
    <?php endif; ?>
            <div class="bg-white p-4 sm:px-6 sm:py-4 border-b border-gray-150">
                <?php if(isset($title)): ?>
                    <h3 class="text-lg leading-6 font-medium text-gray-900">
                        <?php echo e($title); ?>

                    </h3>
                <?php endif; ?>
            </div>
            <div class="bg-white px-4 sm:p-6">
                <div class="space-y-6">
                    <?php echo e($content); ?>

                </div>
            </div>

            <div class="bg-white justify-end px-4 pb-5 sm:px-4 sm:space-x-6 sm:flex">
                <?php echo e($buttons); ?>

            </div>

    <?php if($formAction): ?>
        </form>
    <?php endif; ?>
</div><?php /**PATH T:\laragon\www\Laravel\Emart-system\resources\views/components/modal.blade.php ENDPATH**/ ?>