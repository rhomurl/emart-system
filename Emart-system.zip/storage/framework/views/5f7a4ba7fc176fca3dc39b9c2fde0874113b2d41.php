<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <meta name="description" content="The owner of the Allena Mindoro Store is Mrs. Emelina Almarez, they started their business on May, 2006. They started with a small store and only sold a few. Gradually it grew, developed and had several more brances due to the cooperation of the siblings of the owner of this store.">
        <meta name="keywords" content="e-mart, Allena mindoro store, balete batangas">

        
        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

        <title><?php echo e(config('app.name', 'Laravel')); ?></title>
        <link href="images/favicon.ico" rel="shortcut icon" type="image/x-icon">
        <!-- Fonts -->
        <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Nunito:wght@400;600;700&display=swap">

        <!-- Styles -->
        <link rel="stylesheet" href="<?php echo e(mix('css/app.css')); ?>">
        
        <style>
        /*body {
            background-image: url('images/user-bg.svg');
            background-repeat: no-repeat;
            background-size: cover;
        }*/    
        </style>

        <?php echo \Livewire\Livewire::styles(); ?>


        <!-- Scripts -->
        <script src="<?php echo e(mix('js/app.js')); ?>" defer></script>

        <!-- jQuery -->
        <script src="<?php echo e(asset("js/jquery-2.0.0.min.js")); ?>" type="text/javascript"></script>

        <!-- Bootstrap4 files-->
        <script src="<?php echo e(asset("js/bootstrap.bundle.min.js")); ?>" type="text/javascript"></script>
        <link href="<?php echo e(asset("css/bootstrap.css")); ?>" rel="stylesheet" type="text/css"/>

        <!-- Font awesome 5 -->
        <link href="<?php echo e(asset("fonts/fontawesome/css/all.min.css")); ?>" type="text/css" rel="stylesheet">

        <!-- custom style -->
        <link href="<?php echo e(asset("css/ui.css")); ?>" rel="stylesheet" type="text/css"/>
        <link href="<?php echo e(asset("css/responsive.css")); ?>" rel="stylesheet" type="text/css" />

        <!-- custom javascript -->
        <script src="<?php echo e(asset("js/script.js")); ?>" type="text/javascript"></script>

    </head>
    <body class="font-sans antialiased">
        <b class="screen-overlay"></b>

       <?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        
        <div>
            <!-- Page Content -->
                <?php echo e($slot); ?>

        </div>

        <?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        
        <?php echo $__env->yieldPushContent('modals'); ?>

        <?php echo \Livewire\Livewire::scripts(); ?>    
    </body>
</html>
<?php /**PATH T:\laragon\www\Laravel\Emart-system\resources\views/layouts/guest.blade.php ENDPATH**/ ?>