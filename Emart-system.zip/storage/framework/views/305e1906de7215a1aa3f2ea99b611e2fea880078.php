<?php $__env->startSection('title'); ?>
    My Orders
<?php $__env->stopSection(); ?>

<div>
    <?php if($orders): ?>
        <?php echo e($orders->links()); ?>

    <?php endif; ?>
    
    <?php $__empty_1 = true; $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <article class="card mb-4">
        <header class="card-header">
            

            <strong class="d-inline-block mr-3">Order ID: <?php echo e($order->id); ?></strong>
            <span class="float-right">Order Date: <?php echo e(\Carbon\Carbon::parse($order->created_at)->isoFormat('MMM Do YYYY')); ?></span>

        </header>
        <div class="card-body">
            <div class="row"> 
                <div class="col-md-8">
                    Status: 
                    <?php if($order->status == "otw"): ?>
                        On the way
                    <?php elseif($order->status == "ordered"): ?>
                        Ordered
                    <?php elseif($order->status == "processing"): ?>
                        Processing
                    <?php elseif($order->status == "delivered"): ?>
                        Delivered
                    <?php endif; ?>
                    <br><br>
                    <a href="<?php echo e(route('user.order.details', $order->id )); ?>" class="btn btn-outline-primary">More Details</a> 
                </div>

                <div class="col-md-4">
                    <h6 class="text-muted">Payment</h6>
                    <span class="text-success">
                        Cash on Delivery
                    </span>
                    <p>Subtotal: ₱ <?php echo e($order->subtotal); ?> <br>
                        Shipping fee: ₱ 
                        <?php if(!$order->shippingfee): ?>
                        0.00
                        <?php else: ?>
                            <?php echo e($order->shippingfee); ?>

                        <?php endif; ?> <br> 
                        <?php if($order->discount): ?>
                            <span class="b">Discount: ₱  <?php echo e($order->discount); ?> </span><br>
                        <?php endif; ?>
                        <span class="b">Total: ₱ <?php echo e($order->total); ?> </span>
                    </p>
                </div>
            </div> <!-- row.// -->
        </div> <!-- card-body .// -->

        </article> <!-- card order-item .// -->
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        No orders found
    <?php endif; ?>
</div>
<?php /**PATH T:\laragon\www\Laravel\Emart-system\resources\views/livewire/user/my-orders.blade.php ENDPATH**/ ?>