<div class="container">


    <!-- ============================  FILTER TOP  ================================= -->
    <div class="card mb-3">
        <div class="card-body">
            <ol class="breadcrumb float-left">
                <li class="breadcrumb-item"><a href="<?php echo e(route('user_home')); ?>">Home</a></li>
                <li class="breadcrumb-item"><a href="#">Category Type</a></li>
                <li class="breadcrumb-item active"><?php echo e($this->slug); ?></li>
            </ol>
        </div> <!-- card-body .// -->
    </div> <!-- card.// -->
    <!-- ============================ FILTER TOP END.// ================================= -->
    
    
    <div class="row">
        
        <main class="col-md-12">
    
    
    <header class="mb-3">
            <div class="form-inline">
                <strong class="mr-md-auto"><?php echo e($resultCount); ?> products found </strong>
                <span class="mr-3">Products per page</span>
                <select wire:model="perpage" class="mr-2 form-control">
                    <option>10</option>
                    <option>25</option>
                    <option>50</option>
                    <option>100</option>
                </select>
            </div>
    </header><!-- sect-heading -->
    
    <?php $__empty_1 = true; $__currentLoopData = $results; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $result): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <article class="card card-product-list">
            <div class="row no-gutters">
                <aside class="col-md-3">
                    <a href="<?php echo e(route('product.details', $result->slug )); ?>" class="img-wrap">
                        <span class="badge badge-danger"> NEW </span>
                        <img src="<?php echo e(asset('storage')); ?>/<?php echo e($result->image); ?>">
                    </a>
                </aside> <!-- col.// -->
                <div class="col-md-6">
                    <div class="info-main">
                        <a href="<?php echo e(route('product.details', $result->slug )); ?>" class="h5 title"><?php echo e($result->name); ?></a>
                        <div class="rating-wrap mb-2">
                            
                            <div class="label-rating"><?php echo e($result->brand->name); ?></div>
                        </div> <!-- rating-wrap.// -->
                    
            
                        <p><?php echo e($result->description); ?> </p>
        
                    </div> <!-- info-main.// -->
                </div> <!-- col.// -->
                <aside class="col-sm-3">
                    <div class="info-aside">
                        <div class="price-wrap">
                            <span class="h5 price">₱ <?php echo e($result->selling_price); ?></span> 
                            <small class="text-muted">/per item</small>
                        </div> <!-- price-wrap.// -->
                        <small class="text-warning"></small>
                        
                        <p class="text-muted mt-3"><?php echo e($result->category->name); ?></p>
                        <p class="mt-3">
                            
                            <?php if($result->quantity): ?>
                            <?php if(auth()->check() && auth()->user()->hasRole('admin')): ?>
                            <a wire:click.prevent="addToCart(<?php echo e($result->id); ?>)" href="#" class="btn btn-outline-primary"> Add to Cart </a>
                            <?php endif; ?>
                            <?php else: ?>
                                Out of stock
                            <?php endif; ?>
                        </p>
                    </div> <!-- info-aside.// -->
                </aside> <!-- col.// -->
            </div> <!-- row.// -->
        </article> <!-- card-product .// -->
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        No products found
    <?php endif; ?>
    
    
    <?php echo e($results->links()); ?>

    
    
        </main> <!-- col.// -->
    
    </div>
    
    </div><br><br><?php /**PATH T:\laragon\www\Laravel\Emart-system\resources\views/livewire/shop/category-type.blade.php ENDPATH**/ ?>