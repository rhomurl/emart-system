<tr class="text-gray-700 dark:text-gray-400">
    <td colspan="3" class="w-full px-4 py-3">No results</td>
</tr>