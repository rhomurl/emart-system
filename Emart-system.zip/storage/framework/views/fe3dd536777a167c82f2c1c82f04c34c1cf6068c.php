<section class="section-content bg-white padding-y">
  <div class="container">

    <ol class="breadcrumb py-2">
      <li class="breadcrumb-item"><a href="<?php echo e(route('user_home')); ?>">Home</a></li>
      <li class="breadcrumb-item"><a href="<?php echo e(route('shop.searchcategory', $product->category->slug)); ?>"><?php echo e($product->category->name); ?> - <?php echo e($product->category->type); ?></a></li>
      <li class="breadcrumb-item active" aria-current="page"><?php echo e($product->name); ?></li>
  </ol>
  <!-- ============================ ITEM DETAIL ======================== -->
      <div class="row">
          <aside class="col-md-6">
  <div class="card">
  <article class="gallery-wrap"> 
      <div class="img-big-wrap">
        <div> <a href="#"><img src="<?php echo e(asset('storage')); ?>/<?php echo e($product->image); ?>" onerror="this.src='<?php echo e(asset('storage/app/public/')); ?>/<?php echo e($product->image); ?>'"></a></div>
      </div> <!-- slider-product.// -->

      <!--<div class="thumbs-wrap">
        <a href="#" class="item-thumb"> <img src="images/items/15.jpg"></a>
        <a href="#" class="item-thumb"> <img src="images/items/15-1.jpg"></a>
        <a href="#" class="item-thumb"> <img src="images/items/15-2.jpg"></a>
        <a href="#" class="item-thumb"> <img src="images/items/15-1.jpg"></a>
      </div> slider-nav.// -->
  </article> <!-- gallery-wrap .end// -->
  </div> <!-- card.// -->
          </aside>
          <main class="col-md-6">
  <article class="product-info-aside">
  
  <h2 class="title mt-3"><?php echo e($product->name); ?></h2>
  
  <!--<div class="rating-wrap my-3">
      <ul class="rating-stars">
          <li style="width:80%" class="stars-active"> 
              <i class="fa fa-star"></i> <i class="fa fa-star"></i> 
              <i class="fa fa-star"></i> <i class="fa fa-star"></i> 
              <i class="fa fa-star"></i> 
          </li>
          <li>
              <i class="fa fa-star"></i> <i class="fa fa-star"></i> 
              <i class="fa fa-star"></i> <i class="fa fa-star"></i> 
              <i class="fa fa-star"></i> 
          </li>
      </ul>
      <small class="label-rating text-muted">132 reviews</small>
      <small class="label-rating text-success"> <i class="fa fa-clipboard-check"></i> 154 orders </small
  </div> rating-wrap.// -->
  
  <div class="mb-3"> 
      <var class="price h4">₱ <?php echo e($product->selling_price); ?></var> 
      <!--<span class="text-muted">USD 562.65 incl. VAT</span> !-->
  </div> <!-- price-detail-wrap .// -->
  
  <dl class="row">
    <dt class="col-sm-3">Brand</dt>
    <dd class="col-sm-9"><a href="#"><?php echo e($product->brand->name); ?></a></dd>
  
    <dt class="col-sm-3">Availabilty</dt>
    <dd class="col-sm-9"><?php echo e($product->quantity == '0' ? 'Out of Stock' : 'In Stock'); ?></dd>

    <dt class="col-sm-3 mt-2">Quantity</dt>
    <dd class="col-sm-9">
      <div class="form-group col-md flex-grow-0">
        <div class="input-group mb-2 input-spinner">
          <div class="input-group-prepend">
            <button wire:click.prevent="minusQty" class="btn btn-light" type="button" id="button-minus"> - </button>
          </div>
          <input wire:model="qty" type="text" class="form-control">
          <div class="input-group-append">
            <button wire:click.prevent="addQty" class="btn btn-light" type="button" id="button-plus"> + </button>
          </div>
        </div>
        <?php echo e($product->quantity); ?> pieces available
    </div> <!-- col.// -->
    

    </dd>
  </dl>
      <?php if(auth()->check() && auth()->user()->hasRole('customer')): ?>
      <div class="form-row">
          <div class="form-group col-md">
            <?php if($product->quantity == 0): ?>
              
            <?php else: ?>
                <?php if(!$this->qty): ?>
                  <a wire:click.prevent="addToCart(<?php echo e($product->id); ?>, 1)" href="#" class="btn btn-primary"><i class="fas fa-shopping-cart"></i> <span class="text">Add to cart</span></a>  
                <?php else: ?> 
                  <a wire:click.prevent="addToCart(<?php echo e($product->id); ?>, <?php echo e($this->qty); ?>)" href="#" class="btn btn-primary"><i class="fas fa-shopping-cart"></i> <span class="text">Add to cart</span></a> 
                <?php endif; ?>
              
            <?php endif; ?>
                  
          </div> <!-- col.// -->
      </div> <!-- row.// -->
      <?php endif; ?>
  <hr>
  </article> <!-- product-info-aside .// -->
          </main> <!-- col.// -->
      </div> <!-- row.// -->
  
  <!-- ================ ITEM DETAIL END .// ================= -->
  
  
  </div> <!-- container .//  -->
  </section>

  <!-- ========== SECTION START // ============================ -->
  <section class="section-name padding-y bg">
    <div class="container">
    
    <div class="row">
      <div class="col-md-8">
        <h5 class="title-description">Description</h5>
        <p>
          <?php echo e($product->description); ?>

        </p>

    
      </div> <!-- col.// -->
      
    </div> <!-- row.// -->
    
    </div> <!-- container .//  -->
    </section>
    <!--============ SECTION END=============-->



<div class="container">
  <div class="card card-body">
    
    <h5 class="title-description">Related products</h5>
    <div class="row">
      <?php $__currentLoopData = $related_products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $related_product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <div class="col-md-3">
        <figure class="itemside mb-2">
          <div class="aside">
            <a href="<?php echo e(route('product.details', $related_product->slug )); ?>">
              <img src="<?php echo e(asset('storage')); ?>/<?php echo e($related_product->image); ?>" onerror="this.src='<?php echo e(asset('storage/app/public/')); ?>/<?php echo e($related_product->image); ?>'" class="border img-sm">
            </a>
            </div>
          <figcaption class="info align-self-center">
            <a href="<?php echo e(route('product.details', $related_product->slug )); ?>" class="title"><?php echo e($related_product->name); ?></a>
            <strong class="price">₱ <?php echo e($related_product->selling_price); ?></strong>
          </figcaption>
        </figure>
      </div> <!-- col.// -->
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> <!-- col.// -->
    </div> <!-- row.// -->
  </div>
</div><br><br><?php /**PATH T:\laragon\www\Laravel\Emart-system\resources\views/livewire/shop/product-details.blade.php ENDPATH**/ ?>