<?php $__env->startSection('title'); ?>
    Edit Profile
<?php $__env->stopSection(); ?>

<div>
    <?php if($this->error_message): ?>
    <div class="alert alert-warning" role="alert">
        <?php echo e($this->error_message); ?>

    </div>
    <?php elseif($this->success_message): ?>
    <div class="alert alert-success" role="alert">
        <?php echo e($this->success_message); ?>

    </div>
    <?php endif; ?>
    
    <div class="card-body">
        <form wire:submit.prevent="editInfo" class="mb-5">
         <?php echo e(csrf_field()); ?>

           <div class="form-row">
               <div class="col form-group">
                   <label>Name</label>
                     <input wire:model="firstname" type="text" class="form-control" required>
                     <?php $__errorArgs = ['entry_firstname'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                         <span class="text-danger">
                             <?php echo e($message); ?>

                         </span>
                     <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
               </div> <!-- form-group end.// -->
               <div class="col form-group">
                   <label>Last Name</label>
                     <input wire:model="lastname" type="text" class="form-control" required>
                     <?php $__errorArgs = ['entry_lastname'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                         <span class="text-danger">
                             <?php echo e($message); ?>

                         </span>
                     <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
               </div> <!-- form-group end.// -->
           </div> <!-- form-row.// -->

 
           <div class="form-row">
             <div class="col form-group">
                 <label>Email</label>
                   <input wire:model="email" type="email" class="form-control" value="" disabled>
             </div> <!-- form-group end.// -->
         </div> <!-- form-row.// -->
        
           <button class="btn btn-primary btn-block">Save Changes</button>
         </form>
         </div> 
</div>
<?php /**PATH T:\laragon\www\Laravel\Emart-system\resources\views/livewire/user/settings.blade.php ENDPATH**/ ?>