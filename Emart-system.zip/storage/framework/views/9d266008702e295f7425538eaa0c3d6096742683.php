<?php if (isset($component)) { $__componentOriginalc3251b308c33b100480ddc8862d4f9c79f6df015 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\GuestLayout::class, []); ?>
<?php $component->withName('guest-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
    <section class="section-content padding-y" style="min-height:20vh">
    <div class="card mx-auto" style="max-width:520px; margin-top:40px;">
    <!-- ============================ COMPONENT LOGIN   ================================= -->
        
        <div class="card-body">
        <h4 class="card-title mb-4">Sign in</h4>
        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.validation-errors','data' => ['class' => 'mb-4']]); ?>
<?php $component->withName('jet-validation-errors'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => 'mb-4']); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
        <form method="POST" action="<?php echo e(route('login')); ?>">
                <?php echo csrf_field(); ?>

            <div class="form-group">
                <input id="email" name="email" class="form-control" placeholder="Email" type="email" name="email" :value="old('email')" required autofocus >
            </div> <!-- form-group// -->
            
            <div class="form-group">
                <input input id="password" name="password" class="form-control" placeholder="Password" class="block mt-1 w-full" type="password" name="password" required>
            </div> <!-- form-group// -->
            
            <div class="form-group">
                <?php if(Route::has('password.request')): ?>
                    <a href="<?php echo e(route('password.request')); ?>" class="float-right"><?php echo e(__('Forgot your password?')); ?></a> 
                <?php endif; ?>
                <label class="float-left custom-control custom-checkbox"> <input type="checkbox" id="remember_me" name="remember" class="custom-control-input" checked=""> <div class="custom-control-label"> Remember </div> </label>
            </div> <!-- form-group form-check .// -->
            <div class="form-group">
                <button type="submit" class="btn btn-primary btn-block"> Login  </button>
            </div> <!-- form-group// -->    
        </form>
        </div> <!-- card-body.// -->
        <!-- card .// -->

    <!-- ============================ COMPONENT LOGIN  END.// ================================= -->
    </div>
    <p class="text-center mt-4">Don't have account? <a href="<?php echo e(route('register')); ?>">Sign up</a></p>
    <br>
    </section>
 <?php if (isset($__componentOriginalc3251b308c33b100480ddc8862d4f9c79f6df015)): ?>
<?php $component = $__componentOriginalc3251b308c33b100480ddc8862d4f9c79f6df015; ?>
<?php unset($__componentOriginalc3251b308c33b100480ddc8862d4f9c79f6df015); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php /**PATH T:\laragon\www\Laravel\Emart-system\resources\views/auth/login.blade.php ENDPATH**/ ?>