<div class="widget-header">
    <a href="#" class="widget-view">
        <div class="icon-area">
            <i class="fa fa-shopping-cart">
                <span class="notify">2</span>
            </i>
        </div>
        <small class="text"> Cart </small>
    </a>
</div>

<?php /**PATH T:\laragon\www\Laravel\Emart-system\resources\views/livewire/shop/cart-counter.blade.php ENDPATH**/ ?>