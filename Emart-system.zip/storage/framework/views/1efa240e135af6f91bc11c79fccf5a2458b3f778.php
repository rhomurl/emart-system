<?php $__env->startSection('title', 'Order Details'); ?>
<div>
    <a href="<?php echo e(route('user.orders')); ?>" class="btn btn-primary"> <i class="fa fa-chevron-left"></i> Back to My Orders</a><br><br>

    
    <article class="card mb-4">
        <header class="card-header">
            <strong class="d-inline-block mr-3">Order ID: <?php echo e($order->id); ?></strong>
            <span class="float-right">Order Date and Time: <?php echo e(\Carbon\Carbon::parse($order->created_at)->format('F j Y h:i A')); ?></span>
        </header>
        <div class="card-body">
            <div class="tracking-wrap">
                <div class="step <?php echo e($order->status == 'ordered' ? 'active' : 'active'); ?>">
                    <span class="icon"> <i class="fa fa-check"></i> </span>
                    <span class="text">Order Placed</span>
                </div> <!-- step.// -->
                <div class="step <?php echo e($order->status == 'ordered' ? '' : $order->status == 'processing' ? 'active' : $order->status == 'otw' ? 'active' : $order->status == 'delivered' ? 'active' : ''); ?>">
                    <span class="icon"> <i class="fa fa-user"></i> </span>
                    <span class="text">Processing</span>
                </div> <!-- step.// -->
                <div class="step <?php echo e($order->status == 'ordered' ? '' : $order->status == 'processing' ? '' : $order->status == 'otw' ? 'active' : $order->status == 'delivered' ? 'active' : ''); ?>">
                    <span class="icon"> <i class="fa fa-truck"></i> </span>
                    <span class="text">On the way</span>
                </div> <!-- step.// -->
                <div class="step <?php echo e($order->status == 'ordered' ? '' : $order->status == 'processing' ? '' : $order->status == 'otw' ? '' : $order->status == 'delivered' ? 'active' : ''); ?>">
                    <span class="icon"> <i class="fa fa-box"></i> </span>
                    <span class="text">Delivered</span>
                </div> <!-- step.// -->
            </div><br>

            <div class="row"> 
                <div class="col-md-8">
                    <h6 class="text-muted">Delivery to</h6>
                    <p><?php echo e($address->entry_firstname); ?> <?php echo e($address->entry_lastname); ?> <br>  
                        <?php if($address->entry_company): ?>
                            <?php echo e($address->entry_company); ?><br>
                        <?php endif; ?>
                        <b>Landmark:</b> <?php echo e($address->entry_landmark); ?><br>
                        <?php echo e($address->entry_street_address); ?><br> <?php echo e($address->barangay->name); ?>, <?php echo e($address->barangay->city->name); ?>, <?php echo e($address->barangay->city->zip); ?><br><?php echo e($address->entry_phonenumber); ?>  
                    </p>
                </div>

                
                <div class="col-md-4">
                    <h6 class="text-muted">Payment</h6>
                    <span class="text-success">
                        Cash on Delivery
                    </span>
                    <p>Subtotal: ₱ <?php echo e($order->subtotal); ?> <br>
                        Shipping fee: ₱ 
                        <?php if(!$order->shippingfee): ?>
                        0.00
                        <?php else: ?>
                            <?php echo e($order->shippingfee); ?>

                        <?php endif; ?> <br> 
                        <?php if($order->discount): ?>
                            <span class="b">Discount: ₱  <?php echo e($order->discount); ?> </span><br>
                        <?php endif; ?>
                        <span class="b">Total: ₱ <?php echo e($order->total); ?> </span>
                    </p>
                </div>
            </div> <!-- row.// -->
        </div> <!-- card-body .// -->
        
        <div class="table-responsive">
        <table class="table table-hover ml-5">
                <tbody>
        <p class="p-2">Products</p>
            <?php $__currentLoopData = $order->orderProduct; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <ul class="row">
                <li class="col-md-5">
                    <figure class="itemside mb-3">
                        <div class="aside"><img src="<?php echo e(asset('storage')); ?>/<?php echo e($item->product->image); ?>" onerror="this.src='<?php echo e(asset('storage/app/public/')); ?>/<?php echo e($item->product->image); ?>'" class="img-sm border"></div>
                        <figcaption class="info align-self-center">
                            <p class="title"><?php echo e($item->product->name); ?></p>
                            <span class="text-muted">₱ <?php echo e($item->price); ?> <br> Qty: <?php echo e($item->quantity); ?></span>
                        </figcaption>
                    </figure> 
                </li>
            </ul>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody></table>
        </div> <!-- table-responsive .end// -->
    </article>
</div><?php /**PATH T:\laragon\www\Laravel\Emart-system\resources\views/livewire/user/order-details.blade.php ENDPATH**/ ?>