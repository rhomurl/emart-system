
<div class="container" style="max-width:720px;">
  <?php if($this->checkout_message): ?>
    <div class="alert alert-danger" role="alert">
        <?php echo e($this->checkout_message); ?>

    </div>
  <?php endif; ?>
  <form wire:submit.prevent="placeOrder">
         
    <h4 class="card-title mb-4">Delivery Address</h4>
  <div class="row">
    

    <?php $__empty_1 = true; $__currentLoopData = $addresses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $address): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
          <div class="col-md-6">
              <article class="box mb-4">
                  <h6><?php echo e($address->entry_firstname); ?> <?php echo e($address->entry_lastname); ?></h6>
                  <p>
                    <?php if($address->entry_company): ?>
                        <?php echo e($address->entry_company); ?><br>
                    <?php endif; ?>
                    <?php echo e($address->entry_street_address); ?><br>
                    <b>Landmark:</b> <?php echo e($address->entry_landmark); ?>

                    <br> <?php echo e($address->barangay->name); ?>, 
                    <?php echo e($address->barangay->city->name); ?>, 
                    <?php echo e($address->barangay->city->zip); ?>

                    <br><?php echo e($address->entry_phonenumber); ?>  
                </p>
                  <input wire:model="address_book_id" value="<?php echo e($address->id); ?>" type="radio" name="address">
              </article>
          </div>  <!-- col.// -->
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
      <a href="<?php echo e(route('user.address.create')); ?>" class="btn btn-light mb-3"> <i class="fa fa-plus"></i> Add new address </a>
    <?php endif; ?>
    <?php $__errorArgs = ['address_book_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
    
      <span class="text-danger">
        <br> <?php echo e($message); ?>

      </span>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

  <main class="col-md-12">
        
  <div class="card">
    <h4 class="card-title ml-3 mt-3">Products</h4>

      <table class="table table-borderless table-shopping-cart">
      <thead class="text-muted">
      <?php if(!$cartItems->count() == 0): ?>
          <tr class="small text-uppercase">
          <th scope="col" width="240">Product</th>
          <th scope="col" width="120">Quantity</th>
          <th scope="col" width="120">Price</th>
          </tr>
      <?php endif; ?>
      </thead>
      <tbody>
      <?php $__currentLoopData = $cartItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cartItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <tr>
              <td>
                  <figure class="itemside">
                      <div class="aside">
                          <a href="#">
                          <img src="<?php echo e(asset('storage')); ?>/<?php echo e($cartItem->image); ?>" onerror="this.src='<?php echo e(asset('storage/app/public/')); ?>/<?php echo e($cartItem->image); ?>'" class="img-sm">
                          </a>
                      </div>
                      <figcaption class="info">
                          <a href="#" class="title text-dark"><?php echo e($cartItem->name); ?></a>
                          <p class="text-muted small">Brand: <?php echo e($cartItem->brand); ?></p>
                      </figcaption>
                  </figure>
              </td>
              <td> 
                  <div class="form-inline">
                      <?php echo e($cartItem->qty); ?>

                  </div>
              </td>
              <td> 
                  <div class="price-wrap"> 
                      <var class="price">₱ <?php echo e($cartItem->selling_price * $cartItem->qty); ?></var> 
                      <small class="text-muted">₱ <?php echo e($cartItem->selling_price); ?>  </small> 
                  </div> <!-- price-wrap .// -->
              </td>
             
          </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

      </tbody>
      </table>
  </div> <!-- card.// -->
  
  <div class="card mt-4 mb-4">
    <div class="card-body">
    <h4 class="card-title mb-4">Payment Method</h4>
    <form role="form" style="max-width:380px;">
      <?php if($this->payment_mode): ?>
        <label class="js-check box active">
      <?php else: ?>
        <label class="js-check box">
      <?php endif; ?>
        <input wire:model="payment_mode" value="cod" type="radio" name="payment_mode">
        <h6 class="title">Cash on Delivery</h6>
        <p class="text-muted">Payment will be given upon delivery</p>
      </label> <!-- form-group.// -->
      <?php $__errorArgs = ['payment_mode'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
      <span class="text-danger">
          <?php echo e($message); ?>

      </span>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div> <!-- card-body.// -->
    
  </div>

  

  <div class="card mb-4">
    <div class="card-body">
    <h4 class="card-title mb-4">Order Total</h4>
      
      
      <span class="text-xl">Subtotal:</span><span class="text-xl"> ₱ <?php echo e($this->totalCart); ?></span><br>
    
      <span class="text-xl">Delivery fee:</span> <span class="text-xl"> ₱ <?php echo e($this->shipping); ?><br>
      <?php if($this->discount): ?>
        <span class="font-bold text-xl">Discount:</span> <span class="text-xl">₱ <?php echo e($this->discount); ?> </span><br>
        <span class="font-bold text-xl">Grand Total:</span> <span class="text-xl">₱ <?php echo e($this->grandTotal - $this->discount); ?> </span>
      <?php else: ?>
      <span class="font-bold text-xl">Grand Total:</span> <span class="text-xl">₱ <?php echo e($this->grandTotal); ?> </span>
      <?php endif; ?>
      <br><br>
      
    </div> 
  </div>
  
  
  <button class="btn btn-primary float-md-right"> Place Order <i class="fa fa-chevron-right"></i> </button>
</form>  
</main>
  </div>
  <div class="card mt-4 mb-4">
    <div class="card-body">
    <h4 class="card-title mb-4">Voucher</h4>
    <form wire:submit.prevent="applyCoupon" style="max-width:380px;">
        <div class="input-group w-50">
          <input wire:model="voucher" type="text" class="form-control">
        </div>
        <?php if($this->voucher_msg): ?>
          <p class="text-danger"><?php echo e($this->voucher_msg); ?></p>
        <?php endif; ?>
        <br>
        <button type="submit" class="btn btn-primary float-md-left">Apply Voucher</button>
    </form>
    
    </div>  
  </div>
</div>


    <br><br> 
    
   <?php /**PATH T:\laragon\www\Laravel\Emart-system\resources\views/livewire/shop/checkout.blade.php ENDPATH**/ ?>