<?php if (isset($component)) { $__componentOriginalc3251b308c33b100480ddc8862d4f9c79f6df015 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\GuestLayout::class, []); ?>
<?php $component->withName('guest-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
    <section class="section-content padding-y">

    <!-- ============================ COMPONENT REGISTER   ================================= -->
        <div class="card mx-auto" style="max-width:520px; margin-top:40px;">
        <article class="card-body">

            <header class="mb-4"><h4 class="card-title">Forgot Password</h4></header>
            <?php if(session('status')): ?>
                <div class="mb-4 text-success">
                    <?php echo e(session('status')); ?>

                </div>
            <?php endif; ?>
            <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.validation-errors','data' => ['class' => 'mb-4']]); ?>
<?php $component->withName('jet-validation-errors'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => 'mb-4']); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
            Forgot your password? No problem. Just let us know your email address and we will email you a password reset link that will allow you to choose a new one. 
            <br><br>
            <form method="POST" action="<?php echo e(route('password.email')); ?>">
                <?php echo csrf_field(); ?>
                   
                    <div class="form-group">
                        <label>Email</label>
                        <input id="email" class="form-control" type="text" name="email" :value="old('email')" required autofocus>
                    </div> 
                
                    <div class="form-group">
                        <button type="submit" class="btn btn-primary btn-block"> Email Password Reset Link  </button>
                    </div> <!-- form-group// -->    
                    
                   
                </form>
            </article><!-- card-body.// -->
        </div> <!-- card .// -->
        <br><br>
    <!-- ============================ COMPONENT REGISTER  END.// ================================= -->
    </section>
 <?php if (isset($__componentOriginalc3251b308c33b100480ddc8862d4f9c79f6df015)): ?>
<?php $component = $__componentOriginalc3251b308c33b100480ddc8862d4f9c79f6df015; ?>
<?php unset($__componentOriginalc3251b308c33b100480ddc8862d4f9c79f6df015); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php /**PATH T:\laragon\www\Laravel\Emart-system\resources\views/auth/forgot-password.blade.php ENDPATH**/ ?>