<?php $__env->startSection('title', 'Order Details - Order #' . $order->id ); ?>

<div class="container grid px-6 mx-auto">
    <h2 class="my-6 text-2xl font-semibold text-gray-700 dark:text-gray-200">
        <?php echo $__env->yieldContent('title'); ?>
    </h2>

<?php if($message = Session::get('message')): ?>
    <div role="alert">
    <div class="bg-green-500 text-white font-bold rounded-t px-4 py-2">
        Success
    </div>
    <div class="mb-5 border border-t-0 border-green-400 rounded-b bg-blue-100 px-4 py-3 text-green-700">
        <p><?php echo e($message); ?></p>
    </div>
    </div>
<?php endif; ?>

    <div class="grid gap-6 mb-8 md:grid-cols-2">
        <div class="min-w-0 p-4 bg-white rounded-lg shadow-xs dark:bg-gray-800">
            <h4 class="my-6 text-2xl font-semibold text-gray-700 dark:text-gray-200">
                Delivery Address
            </h4>
            <p class="text-gray-600 dark:text-gray-400">
                <?php if($address->entry_company): ?>
                    <?php echo e($address->entry_company); ?><br>
                <?php endif; ?>
                <?php echo e($address->entry_street_address); ?><br>
                <b>Landmark:</b> <?php echo e($address->entry_landmark); ?>

                <br> <?php echo e($address->barangay->name); ?>, 
                <?php echo e($address->barangay->city->name); ?>, 
                <?php echo e($address->barangay->city->zip); ?>

                <br><?php echo e($address->entry_phonenumber); ?>  
            </p>

            <h4 class="my-6 text-2xl font-semibold text-gray-700 dark:text-gray-200">
                Payment Method
            </h4>
            <p class="text-gray-600 dark:text-gray-400">
               Cash on Delivery 
            </p>
        </div>
        <div class="min-w-0 p-4 bg-white rounded-lg shadow-xs dark:bg-gray-800">
            <h4 class="my-6 text-2xl font-semibold text-gray-700 dark:text-gray-200">
                Payment Information
            </h4>
            <p class="text-gray-600 dark:text-gray-400">
                <b>Subtotal:</b> ₱ <?php echo e($order->subtotal); ?><br>
                <b>Shipping:</b> ₱ <?php echo e($order->shippingfee); ?> <br>
                <b>Discount:</b> ₱ <?php echo e($order->discount); ?><br>
                <b>Order Total:</b> ₱ <?php echo e($order->total); ?><br><br>
           
            Order Status:  
            <?php if($order->status == 'ordered'): ?>
                Ordered
            <?php elseif($order->status == 'delivered'): ?>
                Delivered
            <?php elseif($order->status == 'otw'): ?>
                On The Way
            <?php elseif($order->status == 'processing'): ?>
                Processing    
            <?php else: ?>
                <?php echo e($order->status); ?>

            <?php endif; ?>
            
            <?php if(!$status): ?>
                <?php if($order->status == 'processing' || $order->status == 'otw' || $order->status == 'ordered' ): ?>
                    <br><button wire:click.prevent="changeStatus1()" class="px-4 mt-2 py-2 text-sm font-medium leading-5 text-white transition-colors duration-150 bg-purple-600 border border-transparent rounded-lg active:bg-purple-600 hover:bg-purple-700 focus:outline-none focus:shadow-outline-purple">
                    Change Status
                </button>
                <?php elseif($order->status ='delivered'): ?>
                    
                <?php endif; ?>
            <?php endif; ?>

            <?php if($status): ?>
                <select wire:model="order_status" class="block w-sm mt-1 text-sm border rounded appearance-none dark:text-gray-300 dark:border-gray-600 dark:bg-gray-700 form-select focus:border-purple-400 focus:outline-none focus:shadow-outline-purple dark:focus:shadow-outline-gray">
                    <option value="" selected>-- select status --</option>
                    <option value="processing" <?php echo e($order->status == 'processing' ? 'selected': ''); ?>>Processing</option>
                    <option value="otw" <?php echo e($order->status == 'otw' ? 'selected': ''); ?>>On The Way</option>
                    <option value="delivered" <?php echo e($order->status == 'delivered' ? 'selected': ''); ?>>Delivered</option>
                </select>

                <div>
                    <button wire:click.prevent="changeStatus2()" class="px-4 mt-2 py-2 text-sm font-medium leading-5 text-white transition-colors duration-150 bg-purple-600 border border-transparent rounded-lg active:bg-purple-600 hover:bg-purple-700 focus:outline-none focus:shadow-outline-purple">
                    Save Changes
                    </button>
                </div>
                <div>
                    <button wire:click.prevent="cancelStatus()" class="px-4 mt-2 py-2 text-sm font-medium leading-5 text-white transition-colors duration-150 bg-purple-600 border border-transparent rounded-lg active:bg-purple-600 hover:bg-purple-700 focus:outline-none focus:shadow-outline-purple">
                    Cancel
                    </button>
                </div>
            <?php endif; ?>            

            </p>
        </div>
    </div>

    <div class="w-full mb-8 overflow-hidden rounded-lg shadow-xs border border-gray-200 dark:border-gray-700">
        <div class="w-full overflow-x-auto">
            <table class="w-full whitespace-no-wrap">
                <thead>
                    <tr class="text-xs font-semibold tracking-wide text-left text-gray-500 uppercase border-b dark:border-gray-700 bg-gray-50 dark:text-gray-400 dark:bg-gray-800">
                        <th class="px-4 py-3">Product Name</th>
                        <th class="px-4 py-3">Quantity</th>
                        <th class="px-4 py-3">Price</th>
                        <th class="px-4 py-3">Total</th>
                    </tr>
                </thead>
                <tbody class="bg-white divide-y dark:divide-gray-700 dark:bg-gray-800">
                    <?php $__currentLoopData = $order->orderProduct; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr class="text-gray-700 dark:text-gray-400">
                            <td class="px-4 py-3">
                                <div class="flex items-center text-sm">
                                    <!-- Avatar with inset shadow -->
                                    <div class="relative hidden w-8 h-8 mr-3 rounded-full md:block">
                                        <img class="object-cover w-full h-full rounded-full" src="<?php echo e(asset('storage')); ?>/<?php echo e($item->product->image); ?>" onerror="this.src='<?php echo e(asset('storage/app/public/')); ?>/<?php echo e($item->product->image); ?>'" alt="" loading="lazy">
                                        <div class="absolute inset-0 rounded-full shadow-inner" aria-hidden="true"></div>
                                    </div>
                                    <div>
                                        <p class="font-semibold"><?php echo e($item->product->name); ?></p>
                                        <p class="text-xs text-gray-600 dark:text-gray-400">
                                            Brand: <?php echo e($item->product->brand->name); ?>

                                        </p>
                                    </div>
                                </div>
                            </td>
                            <td class="px-4 py-3 text-sm">
                                <?php echo e($item->quantity); ?>

                            </td>
                            <td class="px-4 py-3 text-xs">
                                <span class="px-2 py-1 font-semibold leading-tight text-orange-700 bg-orange-100 rounded-full dark:text-white dark:bg-orange-600">
                                ₱ <?php echo e($item->product->selling_price); ?>

                                </span>
                            </td>
                            <td class="px-4 py-3 text-sm">
                                ₱ <?php echo e($item->quantity * $item->product->selling_price); ?> 
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    
                </tbody>
            </table>
        </div>
    </div>
</div><?php /**PATH T:\laragon\www\Laravel\Emart-system\resources\views/livewire/admin/order-details.blade.php ENDPATH**/ ?>