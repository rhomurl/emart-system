<?php $__env->startSection('title'); ?>
    Manage Address    
<?php $__env->stopSection(); ?>

<?php if($message = Session::get('error_msg')): ?>
    <?php if($addresses->count() < 5): ?>  
    <div class="alert alert-warning" role="alert">
        <?php echo e($message); ?>

    </div>
    <?php endif; ?>
<?php endif; ?>

<?php if($message = Session::get('message')): ?>
    <?php if($addresses->count() < 5): ?>  
    <div class="alert alert-success" role="alert">
        <?php echo e($message); ?>

    </div>
    <?php endif; ?>
<?php endif; ?>

<div class="row">
    <?php $__empty_1 = true; $__currentLoopData = $addresses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $address): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <div class="col-md-6">
            <article class="box mb-4">
                <h6><?php echo e($address->entry_firstname); ?> <?php echo e($address->entry_lastname); ?></h6>
                <p>
                    <?php if($address->entry_company): ?>
                        <?php echo e($address->entry_company); ?><br>
                    <?php endif; ?>
                    <?php echo e($address->entry_street_address); ?><br>
                    <b>Landmark:</b> <?php echo e($address->entry_landmark); ?>

                    <br> <?php echo e($address->barangay->name); ?>, 
                    <?php echo e($address->barangay->city->name); ?>, 
                    <?php echo e($address->barangay->city->zip); ?>

                    <br><?php echo e($address->entry_phonenumber); ?>  
                </p>
                <a wire:click.prevent="edit(<?php echo e($address->id); ?>)" href="#" class="btn btn-light"> <i class="fa fa-pen"></i> </a>
                <a wire:click.prevent="delete(<?php echo e($address->id); ?>)" href="#" class="btn btn-light"> <i class="text-danger fa fa-trash"></i>  </a>
            </article>
        </div>  <!-- col.// -->
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <div class="col-md-6">
            No address found. Add one?
        </div>
    <?php endif; ?>
</div> <!-- row.// -->

<?php if($addresses->count() < 5): ?>  
    <a href="<?php echo e(route('user.address.create')); ?>" class="btn btn-light mb-3"> <i class="fa fa-plus"></i> Add new address </a>
<?php endif; ?>
<?php /**PATH T:\laragon\www\Laravel\Emart-system\resources\views/livewire/user/address-management.blade.php ENDPATH**/ ?>